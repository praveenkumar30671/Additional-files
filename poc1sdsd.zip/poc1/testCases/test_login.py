from selenium.webdriver.common.keys import Keys
from selenium import webdriver
import pytest
from datetime import datetime
import time
from pageObjects.LoginPage import Login_operation
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen

class Test_001_Login:
    #baseURL = "https://localhost:44348/one"
    #username = "Maheswaran"
    #password = "bsh1"

    baseURL = ReadConfig.getApplicationURL()
    username = ReadConfig.get_username()
    password = ReadConfig.get_password()
    logger = LogGen.loggen()



    def test_homePageTitle(self,setup):
        self.logger.info("********** Test_0001_Login started !!!!! ***********")
        self.driver = setup
        time.sleep(15)
        self.driver.get(self.baseURL)
        time.sleep(15)
        act_title = self.driver.title
        if act_title == "B/S/H/":
            assert True
            self.driver.close()
            self.logger.info("********** Title test passed ***********")
        else:
            self.driver.save_screenshot(".\\Screenshorts\\"+"test_homePageTitle.png")
            self.driver.close()
            assert False
            self.logger.error("********** Title test failed ***********")



    def test_Login(self,setup):
        self.logger.info("********** verifying login operation ***********")
        self.driver = setup
        time.sleep(10)
        self.driver.get(self.baseURL)
        self.lp = Login_operation(self.driver)
        self.lp.setUserName(self.username)
        self.lp.setPassword(self.password)
        self.lp.clickLogin()
        self.logger.info("********** verifying login operation ***********")

        self.lp.driver.maximize_window()
        time.sleep(65)
        self.lp.clickProfile()
        time.sleep(10)
        self.lp.clickLogout()

        act_title = self.driver.title
        if act_title == "B/S/H/":
            assert True
            self.driver.close()
            self.logger.info("********** Title test passed ***********")
        else:
            self.driver.save_screenshot(".\\Screenshorts\\"+"test_Login.png")
            self.driver.close()
            assert False
            self.logger.error("********** Title test failed ***********")




