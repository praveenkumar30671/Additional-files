from selenium.webdriver.common.keys import Keys
from selenium import webdriver
import pytest
from datetime import datetime
import time
from pageObjects.LoginPage import Login_operation
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen
from pageObjects.RegisterUser import AddUser
import string
import random
#from selenium.webdriver.support import expected_conditions as EC
#from selenium.webdriver.support.ui import WebDriverWait

class Test_003_AddCustomer:
    baseURL = ReadConfig.getApplicationURL()
    username = ReadConfig.get_username()
    password = ReadConfig.get_password()
    logger = LogGen.loggen()

    def test_addCustomer(self,setup):
        self.logger.info("********** Test_003_AddUSer *********")
        self.driver = setup
        time.sleep(10)
        self.driver.get(self.baseURL)
        self.driver.maximize_window()
        self.lp=Login_operation(self.driver)
        self.lp.setUserName(self.username)
        self.lp.setPassword(self.password)
        self.lp.clickLogin()
        time.sleep(65)
        self.logger.info("******** Login Passed in Test_003 *********")

        self.logger.info("******** Started adding new User *********")

        self.addnewUser= AddUser(self.driver)
        time.sleep(5)
        self.addnewUser.clickonRegisterUser()

        self.logger.info("******** providing user information *********")

        self.addnewUser.setUsername("siva")
        self.addnewUser.setPassword("bsh38")
        self.addnewUser.setProfileimage("https://logodix.com/logo/1086329.png")
        self.addnewUser.setId("9")
        self.addnewUser.setDesignation("Data-Analyst")
        self.addnewUser.setLogintype("admin")
        time.sleep(3)
        self.addnewUser.clickonRegisterUser()
        time.sleep(35)
        self.obj = self.driver.switch_to.alert
        self.obj.accept()

        self.logger.info("******** Saving User Registration Form ********")

        self.logger.info("******** Add User Registration Validation ********")

        self.msg = self.driver.find_element_by_tag_name("body").text

        print(self.msg)
        if '**Registered Successfully**' in self.msg:
            assert True == True
            self.logger.info("******** Add User Test_Case Passed!!!!!!  ********")
        else:
            self.driver.save_screenshot(".\\Screenshorts\\"+"test_addUser_scr.png")
            self.logger.error("******** Add user Test_case Failed")
            assert True == False
        self.driver.close()
        self.logger.info("******** End of the User_Registration Page")





















