import time
from selenium.webdriver.support.ui import Select
import pytest
from selenium import webdriver
from datetime import datetime
from selenium.webdriver.common.keys import Keys

class AddUser:
    lnk_user_reg_page="/html/body/app-root/mat-sidenav-container/mat-sidenav/div/mat-nav-list/mat-list/mat-list-item[1]/div"
    txt_username_input="/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-loginregister/div[2]/div/div/form/div[1]/input"
    txt_password_input="/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-loginregister/div[2]/div/div/form/div[2]/input"
    txt_profile_pic_link="/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-loginregister/div[2]/div/div/form/div[3]/input"
    txt_id_input="/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-loginregister/div[2]/div/div/form/div[4]/input"
    txt_designation_input="/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-loginregister/div[2]/div/div/form/div[5]/input"
    txt_login_type="/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-loginregister/div[2]/div/div/form/div[6]/input"
    btn_submit_click="/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-loginregister/div[2]/div/div/form/button"

    def __init__(self,driver):
        self.driver = driver

    def clickonRegisterUser(self):
        self.driver.find_element_by_xpath(self.lnk_user_reg_page).click()

    def setUsername(self,username):
        self.driver.find_element_by_xpath(self.txt_username_input).send_keys(username)

    def setPassword(self,password):
        self.driver.find_element_by_xpath(self.txt_password_input).send_keys(password)

    def setProfileimage(self,piclink):
        self.driver.find_element_by_xpath(self.txt_profile_pic_link).send_keys(piclink)

    def setId(self,id):
        self.driver.find_element_by_xpath(self.txt_id_input).send_keys(id)

    def setDesignation(self,desgination):
        self.driver.find_element_by_xpath(self.txt_designation_input).send_keys(desgination)

    def setLogintype(self,logintype):
        self.driver.find_element_by_xpath(self.txt_login_type).send_keys(logintype)

    def clickSave(self):
        self.driver.find_element_by_xpath(self.btn_submit_click).click()



