import time
import pytest
from selenium import webdriver
from datetime import datetime
from selenium.webdriver.common.keys import Keys

class Login_operation:
    textbox_username_id="defaultLoginFormEmail"
    textbox_password_id="defaultLoginFormPassword"
    button_login_xpath="/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-login-page/mat-card/button"
    button_Profile_xpath="/html/body/app-root/div[1]/mat-toolbar/a"
    button_Logout_xpath=" /html/body/div/div[2]/div/div/div/mat-card/mat-card-content/a"



    def __init__(self,driver):
        self.driver=driver

    def setUserName(self,username):
        self.driver.find_element_by_id(self.textbox_username_id).clear()
        self.driver.find_element_by_id(self.textbox_username_id).send_keys("Maheswaran")

    def setPassword(self,password):
        self.driver.find_element_by_id(self.textbox_password_id).clear()
        self.driver.find_element_by_id(self.textbox_password_id).send_keys("bsh1")

    def clickLogin(self):
        self.driver.find_element_by_xpath(self.button_login_xpath).click()

    def clickProfile(self):
        self.driver.find_element_by_xpath(self.button_Profile_xpath).click()

    def clickLogout(self):
        self.driver.find_element_by_xpath(self.button_Logout_xpath).click()








