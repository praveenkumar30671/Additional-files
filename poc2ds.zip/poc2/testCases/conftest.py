from selenium import webdriver
import pytest
from selenium.webdriver.chrome.options import Options


@pytest.fixture()
def setup():
    #options=Options()
    #options.headless =True
    #driver = webdriver.chrome(executable_path='./drivers/chromedriver',options=options)
    driver = webdriver.Chrome(executable_path='./drivers/chromedriver')
    return driver