
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
import pytest
from datetime import datetime
import time
from pageObjects.LoginPage import Login_operation
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen
from utilities import XLUtilities



class Test_002_DDT_Login:
    baseURL = ReadConfig.getApplicationURL()
    path=".//TestData/LoginData.xlsx"
    logger = LogGen.loggen()



    def test_Login(self,setup):
        self.logger.info("********** Login Test 002 DDT Login ***********")
        self.logger.info("********** verifying login DDT operation ***********")
        self.driver = setup
        self.driver.get(self.baseURL)
        self.lp = Login_operation(self.driver)

        self.rows=XLUtilities.getRowCount(self.path,'Sheet1')
        print("Number rows in a Excel:",self.rows)

        list_status=[]   #Empty List variable

        for r in range(2,self.rows+1):
            self.user=XLUtilities.readData(self.path,'Sheet1',r,1)
            self.password=XLUtilities.readData(self.path,'Sheet1',r,2)
            self.exp=XLUtilities.readData(self.path,'Sheet1',r,3)

            self.lp.setUserName(self.user)
            self.lp.setPassword(self.password)
            self.lp.clickLogin()
            self.logger.info("********** verifying login operation ***********")

            self.lp.driver.maximize_window()
            time.sleep(65)
            self.lp.clickProfile()
            time.sleep(10)
            self.lp.clickLogout()

            act_title = self.driver.title
            exp_title = "B/S/H/"

            if act_title == exp_title:
                if self.exp=="Pass":
                    self.logger.info("Test passed")
                    #self.lp.clickLogout();
                    list_status.append("Pass")
                    #print("1.1 passed")
                elif self.exp=="Fail":
                    self.logger.info("Test failed")
                    #self.lp.clickLogout();
                    list_status.append("Fail")
                    #print("1.2 passed")

            elif act_title != exp_title:
                if self.exp=='Pass':
                    self.logger.info("Test failed")
                    list_status.append("Fail")
                    #print("2.1 passed")
                elif self.exp=='Fail':
                    self.logger.info("Test passed")
                    list_status.append("Pass")
                    #print("2.2 passed")

        if "fail" not in list_status:
            print ("******  Login_Test_DDT Passed !!!!!  ******")
            self.logger.info("******  Login_Test_DDT Passed !!!!!  ******")
            self.driver.close()
            assert True
            print("there is no fail in the list")
        else:
            print ("******  Login_Test_DDT Failed !!!!!  ******")
            self.logger.info("******  Login_Test_DDT Failed !!!!!  ******")
            self.driver.close()
            assert False
            print("There is a fail case in list")


        print ("***** Login DDT Ended *****")






















